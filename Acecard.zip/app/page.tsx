'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import Header from '@/components/Header'
import DevicePanel from '@/components/DevicePanel'
import TelemetryPanel from '@/components/TelemetryPanel'
import GraphPanel from '@/components/GraphPanel'
import MLDetectionPanel from '@/components/MLDetectionPanel'
import SecurityPanel from '@/components/SecurityPanel'
import RootCausePanel from '@/components/RootCausePanel'
import PredictionPanel from '@/components/PredictionPanel'
import MicroserviceGrid from '@/components/MicroserviceGrid'
import KubernetesFlow from '@/components/KubernetesFlow'
import LogPanel from '@/components/LogPanel'
import ControlPanel from '@/components/ControlPanel'

export interface DashboardState {
  device_name: string
  system_status: 'INITIALIZING' | 'ACTIVE' | 'HEALTHY' | 'WARNING' | 'CRITICAL'
  system_active: boolean
  cpu_usage: number
  memory_usage: number
  packet_loss: number
  response_time: number
  heartbeat_delay: number
  request_rate: number
  anomaly_score: number
  ml_status: 'NORMAL' | 'WARNING' | 'FAILURE'
  ml_confidence: number
  attack_type: string | null
  threat_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | null
  defense_action: string | null
  root_cause: string | null
  predicted_failure: boolean
  prediction_confidence: number
  cpu_history: number[]
  memory_history: number[]
  delay_history: number[]
  services: Record<string, 'RUNNING' | 'RESTARTING'>
  logs: Record<string, string[]>
}

const SERVICES = [
  'edge_device_service',
  'telemetry_service',
  'detection_service',
  'security_service',
  'recovery_service',
  'orchestrator_service',
]

const generateMetrics = (active: boolean, isAnomalous: boolean) => {
  if (!active) {
    return {
      cpu: Math.random() * 15 + 10,
      memory: Math.random() * 20 + 20,
      packet_loss: Math.random() * 0.5,
      response_time: Math.random() * 0.3 + 0.1,
      request_rate: Math.random() * 30 + 10,
    }
  }

  if (isAnomalous) {
    return {
      cpu: Math.random() * 35 + 70,
      memory: Math.random() * 20 + 75,
      packet_loss: Math.random() * 8 + 5,
      response_time: Math.random() * 1 + 1.5,
      request_rate: Math.random() * 400 + 600,
    }
  }

  return {
    cpu: Math.random() * 35 + 40,
    memory: Math.random() * 35 + 50,
    packet_loss: Math.random() * 2,
    response_time: Math.random() * 0.9 + 0.3,
    request_rate: Math.random() * 120 + 80,
  }
}

export default function Dashboard() {
  const [state, setState] = useState<DashboardState>({
    device_name: 'Detecting Edge Device...',
    system_status: 'INITIALIZING',
    system_active: false,
    cpu_usage: 0,
    memory_usage: 0,
    packet_loss: 0,
    response_time: 0,
    heartbeat_delay: 0,
    request_rate: 0,
    anomaly_score: 0,
    ml_status: 'NORMAL',
    ml_confidence: 0,
    attack_type: null,
    threat_level: null,
    defense_action: null,
    root_cause: null,
    predicted_failure: false,
    prediction_confidence: 0,
    cpu_history: [],
    memory_history: [],
    delay_history: [],
    services: {
      edge_device_service: 'RUNNING',
      telemetry_service: 'RUNNING',
      detection_service: 'RUNNING',
      security_service: 'RUNNING',
      recovery_service: 'RUNNING',
      orchestrator_service: 'RUNNING',
    },
    logs: {
      device: [],
      telemetry: [],
      detection: [],
      security: [],
      recovery: [],
      orchestrator: [],
    },
  })

  const telemetryIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const recoveryIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const anomalyFlagRef = useRef<boolean>(false)

  const addLog = useCallback((category: string, message: string) => {
    setState((prev) => ({
      ...prev,
      logs: {
        ...prev.logs,
        [category]: [...(prev.logs[category] || []), message].slice(-10),
      },
    }))
  }, [])

  const handleConnectDevice = useCallback(() => {
    setState((prev) => ({
      ...prev,
      device_name: 'Arduino Uno',
      system_status: 'ACTIVE',
      system_active: true,
    }))
    addLog('device', '[DEVICE] Arduino Uno connected to control plane')
  }, [addLog])

  const handleDeviceDisconnect = useCallback(() => {
    setState((prev) => ({
      ...prev,
      device_name: 'Raspberry Pi',
      system_active: true,
    }))
    addLog('device', '[DEVICE] Switched to Raspberry Pi fallback infrastructure')
  }, [addLog])

  const handleInjectTrafficSpike = useCallback(() => {
    anomalyFlagRef.current = true
    addLog('detection', '[ALERT] Traffic spike injected - initiating threat detection')
    addLog('security', '[THREAT] DDoS pattern detected')
    addLog('security', '[ACTION] Traffic throttling applied')

    setTimeout(() => {
      anomalyFlagRef.current = false
      addLog('recovery', '[RECOVERED] Traffic normalized')
      addLog('orchestrator', '[K8s] Cluster stabilized')
    }, 8000)
  }, [addLog])

  const handleInjectLatencySurge = useCallback(() => {
    anomalyFlagRef.current = true
    addLog('detection', '[ALERT] Latency surge detected - anomaly scoring elevated')
    addLog('security', '[THREAT] MITM attack pattern detected')
    addLog('security', '[ACTION] Secure channel enforced')

    setTimeout(() => {
      anomalyFlagRef.current = false
      addLog('recovery', '[RECOVERED] Network latency normalized')
      addLog('orchestrator', '[K8s] Cluster stabilized')
    }, 8000)
  }, [addLog])

  const handleForceAnomaly = useCallback(() => {
    anomalyFlagRef.current = true
    addLog('detection', '[ALERT] Anomaly threshold exceeded')
    setState((prev) => ({
      ...prev,
      services: {
        ...prev.services,
        detection_service: 'RESTARTING',
        recovery_service: 'RESTARTING',
      },
    }))
    addLog('orchestrator', '[K8s] Restarting failed services...')

    setTimeout(() => {
      anomalyFlagRef.current = false
      setState((prev) => ({
        ...prev,
        services: {
          ...prev.services,
          detection_service: 'RUNNING',
          recovery_service: 'RUNNING',
        },
      }))
      addLog('orchestrator', '[K8s] Services restored to RUNNING')
      addLog('recovery', '[RECOVERED] System health restored')
    }, 6000)
  }, [addLog])

  const handleInjectUnknownAttack = useCallback(() => {
    anomalyFlagRef.current = true
    addLog('detection', '[ALERT] Unknown attack pattern detected')
    addLog('security', '[THREAT] Unclassified anomaly detected')
    addLog('security', '[ACTION] Node isolated for investigation')

    setTimeout(() => {
      anomalyFlagRef.current = false
      addLog('recovery', '[RECOVERED] Node restored and reintegrated')
      addLog('orchestrator', '[K8s] Cluster rebalanced')
    }, 7000)
  }, [addLog])

  useEffect(() => {
    if (state.system_status !== 'ACTIVE') return

    // Real-time telemetry engine
    telemetryIntervalRef.current = setInterval(() => {
      setState((prev) => {
        const metrics = generateMetrics(true, anomalyFlagRef.current)
        const anomalyScore = metrics.response_time * 0.6 + metrics.cpu_usage * 0.01 + metrics.packet_loss * 0.2

        let mlStatus: 'NORMAL' | 'WARNING' | 'FAILURE' = 'NORMAL'
        let mlConfidence = 0
        if (anomalyScore > 1.5) {
          mlStatus = 'FAILURE'
          mlConfidence = Math.min(99, (anomalyScore / 3) * 100)
        } else if (anomalyScore > 0.8) {
          mlStatus = 'WARNING'
          mlConfidence = Math.min(95, (anomalyScore / 2) * 100)
        } else {
          mlConfidence = Math.max(0, 100 - anomalyScore * 50)
        }

        let attackType: string | null = null
        let threatLevel: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL' | null = null
        let defenseAction: string | null = null
        let rootCause: string | null = null

        if (anomalyFlagRef.current) {
          if (metrics.request_rate > 500) {
            attackType = 'DDoS'
            threatLevel = 'CRITICAL'
            defenseAction = 'Traffic throttled'
            rootCause = 'Request rate spike'
          } else if (metrics.packet_loss > 3) {
            attackType = 'MITM'
            threatLevel = 'HIGH'
            defenseAction = 'Secure channel enforced'
            rootCause = 'Network instability'
          } else {
            attackType = 'ANOMALY'
            threatLevel = 'MEDIUM'
            defenseAction = 'Node isolated'
            rootCause = 'Compute overload'
          }
        }

        const newCpuHistory = [...prev.cpu_history, metrics.cpu].slice(-30)
        const newMemoryHistory = [...prev.memory_history, metrics.memory].slice(-30)
        const newDelayHistory = [...prev.delay_history, metrics.response_time].slice(-30)

        // Prediction logic: detect rising trends
        const avgCpuLast5 = newCpuHistory.slice(-5).reduce((a, b) => a + b, 0) / Math.min(5, newCpuHistory.length)
        const avgDelayLast5 = newDelayHistory.slice(-5).reduce((a, b) => a + b, 0) / Math.min(5, newDelayHistory.length)
        const cpuRising = metrics.cpu > avgCpuLast5 + 5
        const delayRising = metrics.response_time > avgDelayLast5 + 0.2
        const packetLossRising = metrics.packet_loss > 1.5
        const predictedFailure = (cpuRising || delayRising || packetLossRising) && newCpuHistory.length > 5
        const predictionConfidence = predictedFailure ? Math.min(95, (anomalyScore * 20) + 45) : 0

        return {
          ...prev,
          cpu_usage: metrics.cpu,
          memory_usage: metrics.memory,
          packet_loss: metrics.packet_loss,
          response_time: metrics.response_time,
          heartbeat_delay: metrics.response_time * 0.8,
          request_rate: metrics.request_rate,
          anomaly_score: anomalyScore,
          ml_status: mlStatus,
          ml_confidence: mlConfidence,
          attack_type: attackType,
          threat_level: threatLevel,
          defense_action: defenseAction,
          root_cause: rootCause,
          predicted_failure: predictedFailure,
          prediction_confidence: predictionConfidence,
          cpu_history: newCpuHistory,
          memory_history: newMemoryHistory,
          delay_history: newDelayHistory,
          system_status: anomalyFlagRef.current ? 'CRITICAL' : mlStatus === 'FAILURE' ? 'WARNING' : 'ACTIVE',
        }
      })
    }, 1000)

    return () => {
      if (telemetryIntervalRef.current) clearInterval(telemetryIntervalRef.current)
    }
  }, [state.system_status])

  return (
    <div className="min-h-screen bg-background">
      <Header deviceName={state.device_name} systemStatus={state.system_status} />

      <main className="px-4 sm:px-6 py-4 sm:py-6 space-y-4 sm:space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 sm:gap-6">
          <DevicePanel deviceName={state.device_name} systemStatus={state.system_status} onConnect={handleConnectDevice} onDisconnect={handleDeviceDisconnect} />
          <TelemetryPanel state={state} />
        </div>

        <GraphPanel state={state} />

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
          <MLDetectionPanel state={state} />
          <SecurityPanel state={state} />
          <PredictionPanel state={state} />
        </div>

        <RootCausePanel state={state} />

        <MicroserviceGrid state={state} />

        <KubernetesFlow state={state} />

        <ControlPanel
          onInjectTraffic={handleInjectTrafficSpike}
          onInjectLatency={handleInjectLatencySurge}
          onForceAnomaly={handleForceAnomaly}
          onInjectUnknownAttack={handleInjectUnknownAttack}
        />

        <LogPanel logs={state.logs} />
      </main>
    </div>
  )
}
